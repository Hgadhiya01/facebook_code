import os, winshell
from win32com.client import Dispatch
import shutil
import winreg
from selenium import webdriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.common.by import By
from pywinauto import Application, Desktop
import webbrowser

driver_path = os.path.abspath("chromedriver.exe")
userdata_path = os.path.join(os.getenv('LOCALAPPDATA'), 'Google\\Chrome\\User Data')
Chrome_profile_directory_path = os.path.abspath("Chrome_Data\\")

def find_chrome_path():
    # Check the default installation path
    default_path = r'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
    if os.path.isfile(default_path):
        return default_path

    default_path = r'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    if os.path.isfile(default_path):
        return default_path

    # Check the registry for other installation paths
    reg_path = r'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe'
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path, 0, winreg.KEY_READ) as key:
        value = winreg.QueryValueEx(key, None)[0]
        if os.path.isfile(value):
            return value

    # Chrome not found
    return None

def create_chrome_shortcut(no):
    # Find the Chrome executable path
    chrome_path = find_chrome_path()

    # Create a Chrome profile directory
    profile_dir = os.path.join(Chrome_profile_directory_path, 'UserProfile_{}'.format(str(no)))
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)

    # Copy an existing Preferences file to the profile directory, chrome://version/
    preferences_file = os.path.join(userdata_path, 'Default\\Preferences')
    if not os.path.exists(preferences_file):
        preferences_file = os.path.join(userdata_path, 'Guest Profile\\Preferences')
    new_preferences_file = os.path.join(profile_dir, 'Preferences')
    shutil.copy(preferences_file, new_preferences_file)

    # Create the shortcut
    shortcut_path = os.path.join(Chrome_profile_directory_path, f"ChromeShortCut_{str(no)}.lnk")

    # Check if the shortcut file exists
    if not os.path.exists(shortcut_path):
        # Create the shortcut
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.TargetPath = chrome_path
        shortcut.Arguments = "--profile-directory=\"UserProfile_" + str(no) + "\""
        shortcut.save()

    # Launch the shortcut
    # os.startfile(shortcut_path)

    return shortcut_path

def launch_chrome_shortcut(no, PROXY):
    profile_dir = os.path.join(Chrome_profile_directory_path, 'UserProfile_{}'.format(str(no)))

    options = webdriver.ChromeOptions()
    options.add_argument("start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument("user-data-dir=" + profile_dir)
    # options.add_argument('--proxy-server=%s' % PROXY)
    driver = webdriver.Chrome(executable_path=driver_path, options=options)
    driver.get("https://mbasic.facebook.com/")

    # Login to Facebook
    email = "100041601044115"
    password = "love@2023"
    email_field: WebElement = driver.find_element(by=By.XPATH, value="//input[@name='email']")
    password_field = driver.find_element(by=By.XPATH, value="//input[@name='pass']")
    login_button = driver.find_element(by=By.XPATH, value="//input[@name='login']")
    email_field.click()
    email_field.clear()
    password_field.click()
    password_field.clear()
    email_field.send_keys(email)
    password_field.send_keys(password)
    login_button.click()
    # searchForMovie = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#search-text")))

    # Close the driver
    driver.quit()


# Example usage
profile_name = 'UserProfile_1'
shortcut_name = 'ChromeShortCut_1'

PROXIES = [{'http': 'http://104.252.131.113:3128'}]

shortcut_path = create_chrome_shortcut(1)
launch_chrome_shortcut(1, PROXIES[0])
