import os
import time, random
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.remote.webelement import WebElement
import asyncio
import json, threading
import pandas as pd
import requests
from requests.exceptions import ProxyError, ReadTimeout, ConnectionError
# import aiohttp
# import openpyxl
# https://mbasic.facebook.com/login/?ref=dbl&fl&login_from_aymh=1
# pyinstaller --onefile your_script.py

chromedriver_path = os.path.abspath("chromedriver.exe")

excelsheet_path = os.path.abspath("Facebook_User_Data.xlsx")
# wb_obj = openpyxl.load_workbook(excelsheet_path)
df = pd.read_excel(excelsheet_path)
max_row = df.shape[0]
max_column = df.shape[1]


class objData:
  Account = ''
  Group = ''
  Post = ''

account_data = []

for a,b,c in zip(df["Account"], df["Group"], df["Post"]):
  obj = objData()

  obj.Account = str(a)
  obj.Group = str(b)
  obj.Post = str(c)

  account_data.append(obj)

def port_fatch():
  try:      
    port_list = []  
    with open('brow_script.bat', 'r') as file:
        lines = file.readlines()
        for line in lines:
          if "port" in str(line):
            index1 = str(line).index('port=') + len('port=')
            index2 = str(line).index(' ', index1)
            port = line[index1:index2]
            port_list.append(port)
    return port_list
  except Exception as e:
    print(e)
    return None


PROXIES = [{ 'http': 'http://104.252.131.113:3128'}]

Chrome_Data_path = os.path.abspath("Chrome_Data\\")

Chrome_Profiles = []

for path in os.listdir(Chrome_Data_path):
    if os.path.isdir(os.path.join(Chrome_Data_path, path)):
        Chrome_Profiles.append(os.path.join(Chrome_Data_path, path))

def optimize_process(i, profile_path, port):

  try:
    options = webdriver.ChromeOptions()
    options.add_argument("start-maximized")
    # options.add_experimental_option("excludeSwitches", ["enable-automation"])
    # options.add_experimental_option('useAutomationExtension', False)
    options.add_experimental_option("debuggerAddress", f"localhost:{port}")
    options.add_argument('--disable-notifications')
    options.add_argument('--disable-geolocation')
    options.add_argument("--disable-features=WebUSB")
    options.add_argument("--disable-extensions")

    options.add_argument('user-agent=Mozilla/5.0 (Linux; Android 11; 10011886A Build/RP1A.200720.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.69 Safari/537.36')
    options.add_argument('Accept=text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8')
    options.add_argument('Accept-Language=en-US,en;q=0.5')
    options.add_argument('Connection=keep-alive')
    options.add_argument('Upgrade-Insecure-Requests=1')
    options.add_argument('Sec-Fetch-Dest=document')
    options.add_argument('Sec-Fetch-Mode=navigate')
    options.add_argument('Sec-Fetch-Site=none')
    options.add_argument('Sec-Fetch-User=?1')
    options.add_argument('Pragma=no-cache')
    options.add_argument('Cache-Control=no-cache')

    options.add_argument("user-data-dir=" + profile_path) #Path to your chrome profile
      

    print(str(i)+" | Port : "+str(port) + " | Start")
    driver = webdriver.Chrome(executable_path=chromedriver_path, options=options)
    wait = WebDriverWait(driver, 10)
    driver.get('https://mbasic.facebook.com/')
    time.sleep(3)
    try:
      driver.maximize_window()
    except Exception as e: 
      print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
      time.sleep(1)
      
    print(str(i)+" | Port : "+str(port) + " | Start Driver")
    try:
      profile_user = driver.find_element(by=By.XPATH, value="//a[text()='Profile']").get_attribute("href")
      index1 = profile_user.index('?')
      profile_user = profile_user[:index1]
      profile_user = profile_user.replace('https://mbasic.facebook.com/','')

      # # Like all posts on first page
      # a_tags = driver.find_elements(by=By.XPATH, value="//a[text()='Like']")  
      # a_tags = [a_tag.get_attribute("href") for a_tag in a_tags]
      # for url in a_tags:
      #     # print(url)
      #     driver.execute_script(f"window.open('{url}', '_blank')")
      #     driver.switch_to.window(driver.window_handles[1])
      #     index1 = url.index('ft_ent_identifier=')
      #     index2 = url.index('&', index1)
      #     id = url[index1+len('ft_ent_identifier='):index2]
      #     time.sleep(3)
      #     try:        
      #       like_parent = driver.find_elements(by=By.XPATH, value=f"//div[@id='actions_{id}']") 
            
      #       like_a = like_parent.find_elements(by=By.XPATH, value="//span[text()='Like']") 
      #       perent_element = like_a.find_element(by=By.XPATH, value="./..")  
      #       driver.get(perent_element.get_attribute("href"))
      #       time.sleep(3)
      #     except Exception as e: 
      #       print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
      #       try:
      #         driver.find_elements(by=By.XPATH, value="//*[@id=\"root\"]/table/tbody/tr/td/ul/li[1]/table/tbody/tr/td/a").click()
      #         time.sleep(3)
      #       except Exception as e: 
      #         print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
      #         time.sleep(1)
      #       finally:
      #         driver.close() # close the new tab
      #         driver.switch_to.window(driver.window_handles[0])

      driver.get('https://mbasic.facebook.com/groups/')
      time.sleep(3)
      
      # Leave Groups
      try:
         
        try:        
          ul_element = driver.find_element(by=By.XPATH, value="//h3[text()='Groups You Are In']")
        except:
          ul_element = driver.find_element(by=By.XPATH, value="//h3[text()='Groups you are in']")
         
        if ul_element is not None :
          perent_element = ul_element.find_element(by=By.XPATH, value="./..") 
          a_tags = perent_element.find_elements(By.XPATH,".//a[@href]")
          group_link = [a_tag.get_attribute("href") for a_tag in a_tags]
          for url in group_link:
              # print(url)
              try:
                driver.get(url)
                time.sleep(3)
                group_id = driver.find_element(By.XPATH, "//meta[@property='al:android:url']")
                group_id = group_id.get_attribute("content").replace('fb://group/', '').strip()
                driver.get(f"https://mbasic.facebook.com/group/leave/?group_id={group_id}")
                time.sleep(3)
                try:
                  driver.find_element(By.XPATH, "//input[@value='Leave Group']").click()
                except:
                  driver.find_element(By.XPATH, "//input[@value='Leave group']").click()
                time.sleep(3)
              except Exception as e: 
                print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
                continue
      except Exception as e: 
        print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
        time.sleep(1)

      # Join Groups
      groups_join = [item.Group for item in account_data if int(item.Account) == int(str(i+1))] # ['2156402857960693','1817927191555403', '380015662050872']  
      groups_join = list(set(groups_join))
      
      if groups_join:
        for gid in groups_join:
          try:
            driver.get(f"https://mbasic.facebook.com/groups/{gid}")
            time.sleep(5)
            driver.find_element(By.XPATH, "//input[@value='Join Group' and @type='submit']").click()
            time.sleep(5)
          except Exception as e: 
            print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
            continue

        driver.get('https://mbasic.facebook.com/groups/')
        time.sleep(3)
        try:
          try:
            ul_element = driver.find_element(by=By.XPATH, value="//h3[text()='Groups You Are In']")
          except:
            ul_element = driver.find_element(by=By.XPATH, value="//h3[text()='Groups you are in']")
          if ul_element is not None :       
            perent_element = ul_element.find_element(by=By.XPATH, value="./..") 
            a_tags = perent_element.find_elements(By.XPATH,".//a[@href]")      
            group_link = [a_tag.get_attribute("href") for a_tag in a_tags]
            for url in group_link:
                # print(url)
                try:
                  driver.get(url)
                  time.sleep(3)
                  group_id = driver.find_element(By.XPATH, "//meta[@property='al:android:url']")
                  group_id = group_id.get_attribute("content").replace('fb://group/', '').strip()
                  
                  # post data on group
                  post_list = [x.Post for x in account_data if int(x.Account) == int(str(i+1)) and x.Group == group_id ]

                  for post_data in post_list:              
                    try:
                      driver.get(f"https://mbasic.facebook.com/groups/{group_id}")
                      time.sleep(3)
                      text_area = driver.find_element(by=By.XPATH, value="//textarea[@name='xc_message']")
                      text_area.send_keys(post_data) 
                      time.sleep(3)
                      driver.find_element(by=By.XPATH, value="//input[@name='view_post']").click()        
                      time.sleep(3)
                    except Exception as e: 
                      print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
                      continue

                  driver.get(f"https://mbasic.facebook.com/groups/{group_id}")
                  
                  # Like all posts on group
                  a_tags = driver.find_elements(by=By.XPATH, value="//a[text()='Like']")  
                  a_tags = [a_tag.get_attribute("href") for a_tag in a_tags]
                  for url in a_tags:
                      # print(url)
                      driver.execute_script(f"window.open('{url}', '_blank')")
                      driver.switch_to.window(driver.window_handles[1])
                      index1 = url.index('ft_ent_identifier=')
                      index2 = url.index('&', index1)
                      id = url[index1+len('ft_ent_identifier='):index2]
                      time.sleep(3)
                      try:        
                        like_parent = driver.find_elements(by=By.XPATH, value=f"//div[@id='actions_{id}']") 
                        
                        like_a = like_parent.find_elements(by=By.XPATH, value="//span[text()='Like']") 
                        perent_element = like_a.find_element(by=By.XPATH, value="./..")  
                        driver.get(perent_element.get_attribute("href"))
                        time.sleep(3)
                      except Exception as e: 
                        print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
                        try:
                          driver.find_elements(by=By.XPATH, value="//*[@id=\"root\"]/table/tbody/tr/td/ul/li[1]/table/tbody/tr/td/a").click()
                          time.sleep(3)
                        except Exception as e: 
                          print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
                          time.sleep(1)
                      finally:
                        driver.close() # close the new tab
                        driver.switch_to.window(driver.window_handles[0])
                  
                except Exception as e: 
                  print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
                  continue
        except Exception as e: 
          print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
          time.sleep(1)
      
    except Exception as e: 
      print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:100])
      time.sleep(3)

    time.sleep(3)
    driver.quit()

  except Exception as e: 
      print(str(i)+" | Port : "+str(port) + " | Error : " + str(e)[:1000])

port_list = port_fatch()
for i in range(0, len(port_list)):
  t2 = threading.Thread(target=optimize_process, args=(i, Chrome_Profiles[i],port_list[i],))
  t2.start()

# optimize_process(0, Chrome_Profiles[0],port_list[0])

# python
# options = Options()
# options.add_argument("--user-data-dir=C:/path/to/profile1")
# options.add_argument("--profile-directory=Profile 1")
#
# driver1 = webdriver.Chrome(ChromeDriverManager().install(), options=options)
#
# options = Options()
# options.add_argument("--user-data-dir=C:/path/to/profile2")
# options.add_argument("--profile-directory=Profile 2")
#
# driver2 = webdriver.Chrome(ChromeDriverManager().install(), options=options)
#
# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# from webdriver_manager.chrome import ChromeDriverManager

# pip install selenium
# pip install webdriver_manager