from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

options = Options()
options.add_argument("--user-data-dir=C:/Users/admin/AppData/Local/Google/Chrome/User Data/Profile 2")
options.add_argument("--profile-directory=C:/Users/admin/AppData/Local/Google/Chrome/User Data/Profile 4")

driver1 = webdriver.Chrome(ChromeDriverManager().install(), options=options)

options = Options()
options.add_argument("--user-data-dir=C:/path/to/profile2")
options.add_argument("--profile-directory=Profile 2")

driver2 = webdriver.Chrome(ChromeDriverManager().install(), options=options)

driver1.get("https://www.skyscanner.co.in/")

driver2.get("https://www.skyscanner.co.in/")