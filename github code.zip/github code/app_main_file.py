from datetime import datetime
import random

from flask import (flash, Flask, redirect, render_template, request,
                   session, url_for)
from pymongo import MongoClient
from flask_mail import Mail
import urllib.request
import os
import subprocess
from werkzeug.utils import secure_filename
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from time import sleep
from flask import session
import csv
import threading

app = Flask(__name__)

# SqlAlchemy Database Configuration With Mysql
app.config.from_pyfile('config.py')

secure_type = "http"


client = MongoClient("mongodb+srv://harshitgadhiya:Hgadhiya8980@codescatter.04ufqjh.mongodb.net/?retryWrites=true&w=majority")

db = client["email_finder_tool"]


def register_data(coll_name, new_dict):
    try:
        coll = db[coll_name]
        coll.insert_one(new_dict)

        return "add_data"

    except Exception as e:
        print(e)


def find_all_cust_details():
    try:
        coll = db["customer_details"]
        res = coll.find({})
        return res

    except Exception as e:
        print(e)


def find_all_cust_details_coll(coll_name):
    try:
        coll = db[coll_name]
        res = coll.find({})
        return res

    except Exception as e:
        print(e)


def find_all_specific_user(coll_name, di):
    try:
        coll = db[coll_name]
        res = coll.find(di)
        return res

    except Exception as e:
        print(e)


def delete_data(coll_name, di):
    try:
        coll = db[coll_name]
        res = coll.delete_one(di)
        return res

    except Exception as e:
        print(e)


def update_data(coll_name, prev_data, update_data):
    try:
        coll = db[coll_name]
        coll.update_one(prev_data, update_data)
        return "updated"

    except Exception as e:
        print(e)


def all_process(username, timing):
    try:
        ser = Service("C:\ztool\chromedriver")
        op = webdriver.ChromeOptions()
        op.add_experimental_option('debuggerAddress', 'localhost:8989')
        driver = webdriver.Chrome(service=ser, options=op)

        driver.get('https://mail.google.com/mail/u/0/#inbox?compose=new')

        sleep(6)
        all_data = find_all_specific_user(coll_name="input_data", di={"username":username, "time": timing})

        # in_file = open(session["csv_file_path"], "r")
        # reader = csv.reader(in_file)
        reader = all_data[0]["data"]

        num = 14
        output_file = []
        log_file = []
        for ind, namemail in enumerate(reader):

            driver.find_element(By.XPATH,'/html/body/div[19]/div/div/div/div[1]/div[2]/div[1]/div[1]/div/div/div/div[3]/div/div/div[4]/table/tbody/tr/td[2]/form/div[1]/table/tbody/tr[1]/td[2]/div/div/div[1]/div/div[3]/div/div/div/div/div/input').send_keys(
                namemail[0] + ' ' + namemail[1] + ' ' + namemail[2])
            sleep(7)
            num += 1
            try:
                mail = ""

                text = driver.find_element(By.XPATH, '/html/body/div[19]/div/div/div/div[1]/div[2]/div[1]/div[1]/div/div/div/div[3]/div/div/div[4]/table/tbody/tr/td[2]/form/div[1]/table/tbody/tr[1]/td[2]/div/div/div[1]/div/div[3]/div/div/div/div/div[1]/div').text
                mail = text.split('\n')[0]

                sleep(0.5)
                driver.find_element(By.XPATH, '/html/body/div[19]/div/div/div/div[1]/div[2]/div[1]/div[1]/div/div/div/div[3]/div/div/div[4]/table/tbody/tr/td[2]/form/div[1]/table/tbody/tr[1]/td[2]/div/div/div[1]/div/div[3]/div/div/div/div/div/input').clear()


                if mail != "":
                    output_file.append(mail)
                    log_file.append(mail)

            except:
                driver.find_element(By.XPATH, '/html/body/div[19]/div/div/div/div[1]/div[2]/div[1]/div[1]/div/div/div/div[3]/div/div/div[4]/table/tbody/tr/td[2]/form/div[1]/table/tbody/tr[1]/td[2]/div/div/div[1]/div/div[3]/div/div/div/div/div/input').clear()

        di_out = {"username": username, "data": output_file, "time": timing}
        di_log = {"username": username, "data": log_file, "time": timing}

        a_out = register_data(coll_name="output_data", new_dict=di_out)
        a_log = register_data(coll_name="log_data", new_dict=di_log)
        return "all_done"

    except Exception as e:
        print(e)
        return "all_done"


@app.route("/email_finding_process", methods=["GET", "POST"])
def email_finding_process():
    if request.method=="POST":
        data = dict(request.form)
        res = all_process(username=data["username"], timing=data["time"])
        return "complete"
    else:
        return "not complete"


if __name__ == "__main__":
    # db.create_all()
    app.run(
        host="127.0.0.1",
        port="8000",
        debug=True)

